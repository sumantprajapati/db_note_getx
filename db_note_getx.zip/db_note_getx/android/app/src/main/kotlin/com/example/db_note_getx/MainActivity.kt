package com.example.db_note_getx

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
